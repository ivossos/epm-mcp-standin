# EPM Copilot — stand-in MCP server (Entra ID)

A rehearsal copy of the on-prem Hyperion/Essbase MCP server. It has the same
tool shape and the same Exec / East / West security, but runs on **synthetic
Demo.Basic data**, so it can live on a public host and prove the full chain:

    Copilot Studio or Claude → Microsoft Entra ID sign-in → this MCP server → filtered answer

When ThoughtLogic publishes the real server, swap the URL; the Entra and
Copilot Studio setup stay the same.

## Tools

| Tool | What it does |
| --- | --- |
| `whoami` | Signed-in user, role and authorised markets |
| `list_dimensions` | Year, Measures, Product, Market (only allowed markets), Scenario |
| `query_data` | Measures by market × product for a period and scenario |
| `variance_actual_vs_budget` | Actual vs Budget for one measure, by Market or Product |

## Security

1. **Token check (every request).** Signature against Entra's keys, issuer
   (your tenant), audience (this API), expiry, and the `access_as_user` scope.
   Anything else gets `401` plus a pointer to the OAuth metadata at
   `/.well-known/oauth-protected-resource/mcp`.
2. **Role check (every tool call).** The user (or an Entra group) maps to a
   role: `exec` = all markets, `east` = East, `west` = West. Asking for a market
   outside the role returns "Access denied" and is written to the audit log.
   Signed-in users with no role get nothing.

Every call is logged as one JSON line on stdout (`whoami`, `query`,
`variance`, `denied`, `token_rejected`). No passwords or tokens are logged.

## Run locally

```bash
pip install -r requirements.txt
cp .env.example .env        # fill in, then export the variables
python -m app.server        # http://localhost:8000/mcp , health at /health
```

For a quick local look without Entra: `ALLOW_NO_AUTH=true NO_AUTH_ROLE=east python -m app.server`.
Never deploy with `ALLOW_NO_AUTH=true`.

## Tests

```bash
pip install -r requirements-dev.txt
pytest -q
```

19 end-to-end tests start the real server and a fake Entra key endpoint, then
check: no token → 401; wrong audience, Graph-only scope, expired, forged,
other-tenant and garbage tokens → 401; Exec sees all markets; East sees only
East; East asking for West is refused; West variance shows only West; group
mapping; signed-in but unmapped users get nothing.

## Deploy

Any host that gives a public HTTPS URL works (Render, Azure App Service,
Azure Container Apps, a VM behind Caddy). `render.yaml` and `Dockerfile` are
included. See `SETUP.md` for the full Entra + Copilot Studio steps.
