"""End-to-end tests: real HTTP server, real MCP client, tokens signed like Entra's.

A local JWKS endpoint stands in for login.microsoftonline.com so we can mint
tokens for the Exec / East / West test users and for bad cases.
"""

from __future__ import annotations

import asyncio
import json
import os
import socket
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer

import httpx
import jwt
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa
from jwt.algorithms import RSAAlgorithm
from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client

TENANT = "11111111-2222-3333-4444-555555555555"
AUDIENCE = "api://epmcopilot-mcp"
KID = "test-key"
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _free_port() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


KEY = rsa.generate_private_key(public_exponent=65537, key_size=2048)
OTHER_KEY = rsa.generate_private_key(public_exponent=65537, key_size=2048)


def mint(user: str, *, aud=AUDIENCE, scp="access_as_user", exp_in=600, key=KEY,
         iss=f"https://login.microsoftonline.com/{TENANT}/v2.0", groups=None) -> str:
    now = int(time.time())
    claims = {"iss": iss, "aud": aud, "iat": now, "nbf": now, "exp": now + exp_in, "scp": scp,
              "preferred_username": user, "azp": "copilot-studio-client", "tid": TENANT}
    if groups:
        claims["groups"] = groups
    return jwt.encode(claims, key, algorithm="RS256", headers={"kid": KID})


@pytest.fixture(scope="module")
def server_url():
    jwk = json.loads(RSAAlgorithm.to_jwk(KEY.public_key()))
    jwk.update({"kid": KID, "use": "sig", "alg": "RS256"})
    body = json.dumps({"keys": [jwk]}).encode()

    class JWKS(BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *a):
            pass

    jwks_port = _free_port()
    httpd = HTTPServer(("127.0.0.1", jwks_port), JWKS)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()

    port = _free_port()
    env = dict(os.environ,
               PORT=str(port),
               PUBLIC_URL=f"http://127.0.0.1:{port}",
               ENTRA_TENANT_ID=TENANT,
               ENTRA_AUDIENCE=AUDIENCE,
               ENTRA_JWKS_URL=f"http://127.0.0.1:{jwks_port}/keys",
               USER_ROLES=json.dumps({"exec@demo.test": "exec", "east@demo.test": "east",
                                      "west@demo.test": "west"}),
               GROUP_ROLES=json.dumps({"grp-east": "east"}),
               ALLOW_NO_AUTH="false")
    proc = subprocess.Popen([sys.executable, "-m", "app.server"], cwd=ROOT, env=env,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    base = f"http://127.0.0.1:{port}"
    for _ in range(100):
        try:
            if httpx.get(f"{base}/health", timeout=0.5).status_code == 200:
                break
        except httpx.HTTPError:
            time.sleep(0.1)
    else:
        proc.kill()
        raise RuntimeError(proc.stdout.read())
    yield base
    proc.terminate()
    out = proc.communicate(timeout=5)[0]
    with open(os.path.join(ROOT, "tests", "last_server_log.txt"), "w") as f:
        f.write(out)
    httpd.shutdown()


def call(base: str, token: str, tool: str, args: dict | None = None) -> dict:
    async def run():
        headers = {"Authorization": f"Bearer {token}"}
        async with streamablehttp_client(f"{base}/mcp", headers=headers) as (r, w, _):
            async with ClientSession(r, w) as s:
                await s.initialize()
                res = await s.call_tool(tool, args or {})
                return json.loads(res.content[0].text)
    return asyncio.run(run())


def list_tools(base: str, token: str) -> list[str]:
    async def run():
        async with streamablehttp_client(f"{base}/mcp", headers={"Authorization": f"Bearer {token}"}) as (r, w, _):
            async with ClientSession(r, w) as s:
                await s.initialize()
                return [t.name for t in (await s.list_tools()).tools]
    return asyncio.run(run())


INIT = {"jsonrpc": "2.0", "id": 1, "method": "initialize",
        "params": {"protocolVersion": "2025-06-18", "capabilities": {},
                   "clientInfo": {"name": "t", "version": "1"}}}
HDRS = {"Accept": "application/json, text/event-stream", "Content-Type": "application/json"}


def raw(base: str, token: str | None):
    h = dict(HDRS)
    if token:
        h["Authorization"] = f"Bearer {token}"
    return httpx.post(f"{base}/mcp", json=INIT, headers=h)


# ---------------- Layer 1: the token itself ----------------
def test_health_is_public(server_url):
    assert httpx.get(f"{server_url}/health").json()["auth"] == "entra"


def test_no_token_gets_401_with_resource_metadata(server_url):
    r = raw(server_url, None)
    assert r.status_code == 401
    assert "resource_metadata" in r.headers.get("www-authenticate", "")


def test_protected_resource_metadata_points_to_entra(server_url):
    r = httpx.get(f"{server_url}/.well-known/oauth-protected-resource/mcp")
    assert r.status_code == 200
    assert TENANT in json.dumps(r.json())


@pytest.mark.parametrize("bad", [
    mint("east@demo.test", aud="api://someone-else"),
    mint("east@demo.test", scp="User.Read"),
    mint("east@demo.test", exp_in=-60),
    mint("east@demo.test", key=OTHER_KEY),
    mint("east@demo.test", iss="https://login.microsoftonline.com/other-tenant/v2.0"),
    "not-a-jwt",
], ids=["wrong-audience", "graph-scope-only", "expired", "forged-signature", "other-tenant", "garbage"])
def test_bad_tokens_rejected(server_url, bad):
    assert raw(server_url, bad).status_code == 401


def test_valid_token_accepted(server_url):
    assert raw(server_url, mint("east@demo.test")).status_code == 200


# ---------------- Layer 2: Essbase-style filters ----------------
def test_tools_listed(server_url):
    assert set(list_tools(server_url, mint("exec@demo.test"))) == {
        "whoami", "list_dimensions", "query_data", "variance_actual_vs_budget"}


def test_whoami_east(server_url):
    r = call(server_url, mint("east@demo.test"), "whoami")
    assert r == {"user": "east@demo.test", "role": "east", "authorised_markets": ["East"]}


def test_exec_sees_all_markets(server_url):
    r = call(server_url, mint("exec@demo.test"), "query_data", {"measures": ["Sales"]})
    assert {row["market"] for row in r["rows"]} == {"East", "West", "South", "Central"}


def test_east_default_query_only_returns_east(server_url):
    r = call(server_url, mint("east@demo.test"), "query_data", {"measures": ["Sales", "Margin"]})
    assert {row["market"] for row in r["rows"]} == {"East"}


def test_east_asking_for_west_is_refused(server_url):
    r = call(server_url, mint("east@demo.test"), "query_data", {"measures": ["Sales"], "markets": ["West"]})
    assert "Access denied" in r["error"] and "West" in r["error"]


def test_west_variance_only_west(server_url):
    r = call(server_url, mint("west@demo.test"), "variance_actual_vs_budget", {"measure": "Profit"})
    assert [row["Market"] for row in r["rows"]] == ["West"]


def test_group_mapping_works(server_url):
    r = call(server_url, mint("someone@demo.test", groups=["grp-east"]), "whoami")
    assert r["authorised_markets"] == ["East"]


def test_signed_in_but_unmapped_user_gets_nothing(server_url):
    r = call(server_url, mint("stranger@demo.test"), "query_data", {"measures": ["Sales"]})
    assert "no access" in r["error"]


def test_numbers_consistent(server_url):
    tok = mint("exec@demo.test")
    q = call(server_url, tok, "query_data", {"measures": ["Sales", "COGS", "Margin"], "markets": ["East"],
                                             "products": ["Colas"], "period": "Qtr1"})
    row = q["rows"][0]
    assert round(row["Sales"] - row["COGS"], 2) == row["Margin"]
