"""Microsoft Entra ID bearer-token verification and user-to-role mapping.

The MCP server acts as an OAuth 2.0 *resource server*: it never sees a
password. Clients (Copilot Studio, Claude) obtain an access token from Entra
and send it as `Authorization: Bearer <token>`. We check signature, issuer,
audience, expiry and scope, then map the signed-in user to a security role
that mirrors an Essbase filter.
"""

from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass, field

import jwt
from jwt import PyJWKClient

from mcp.server.auth.provider import AccessToken

log = logging.getLogger("epm.auth")

# Role -> markets the role may see. Mirrors the Essbase filters on the
# on-prem demo (Exec = all markets, East/West viewers = their own market).
ROLE_MARKETS: dict[str, list[str]] = {
    "exec": ["East", "West", "South", "Central"],
    "east": ["East"],
    "west": ["West"],
}


class EntraAccessToken(AccessToken):
    """AccessToken plus the identity we resolved from the Entra claims."""

    user: str
    role: str | None = None


@dataclass
class EntraConfig:
    tenant_id: str
    audiences: list[str]
    required_scope: str = "access_as_user"
    user_roles: dict[str, str] = field(default_factory=dict)  # upn/email -> role
    group_roles: dict[str, str] = field(default_factory=dict)  # Entra group object id -> role
    jwks_url: str | None = None

    @classmethod
    def from_env(cls) -> "EntraConfig":
        tenant = os.environ["ENTRA_TENANT_ID"]
        audiences = [a.strip() for a in os.environ["ENTRA_AUDIENCE"].split(",") if a.strip()]
        return cls(
            tenant_id=tenant,
            audiences=audiences,
            required_scope=os.environ.get("ENTRA_REQUIRED_SCOPE", "access_as_user"),
            user_roles={k.lower(): v.lower() for k, v in json.loads(os.environ.get("USER_ROLES", "{}")).items()},
            group_roles={k: v.lower() for k, v in json.loads(os.environ.get("GROUP_ROLES", "{}")).items()},
            jwks_url=os.environ.get("ENTRA_JWKS_URL"),
        )

    @property
    def issuers(self) -> list[str]:
        # v2 and v1 access-token issuers for the tenant.
        return [
            f"https://login.microsoftonline.com/{self.tenant_id}/v2.0",
            f"https://sts.windows.net/{self.tenant_id}/",
        ]

    @property
    def authority(self) -> str:
        return f"https://login.microsoftonline.com/{self.tenant_id}/v2.0"


def resolve_role(cfg: EntraConfig, user: str, groups: list[str]) -> str | None:
    """User mapping wins over group mapping; unknown users get no role."""
    role = cfg.user_roles.get(user.lower())
    if role:
        return role
    for g in groups:
        if g in cfg.group_roles:
            return cfg.group_roles[g]
    return None


class EntraTokenVerifier:
    def __init__(self, cfg: EntraConfig, jwk_client: PyJWKClient | None = None):
        self.cfg = cfg
        url = cfg.jwks_url or f"https://login.microsoftonline.com/{cfg.tenant_id}/discovery/v2.0/keys"
        self._jwks = jwk_client or PyJWKClient(url, cache_keys=True, lifespan=3600)

    async def verify_token(self, token: str) -> EntraAccessToken | None:
        try:
            key = self._jwks.get_signing_key_from_jwt(token).key
            claims = jwt.decode(
                token,
                key,
                algorithms=["RS256"],
                audience=self.cfg.audiences,
                issuer=self.cfg.issuers,
                options={"require": ["exp", "iss", "aud"]},
            )
        except Exception as exc:  # invalid signature, expired, wrong aud/iss, ...
            log.warning(json.dumps({"event": "token_rejected", "reason": type(exc).__name__}))
            return None

        scopes = str(claims.get("scp", "")).split()
        if self.cfg.required_scope and self.cfg.required_scope not in scopes:
            log.warning(json.dumps({"event": "token_rejected", "reason": "missing_scope", "scopes": scopes}))
            return None

        user = claims.get("preferred_username") or claims.get("upn") or claims.get("unique_name") or claims.get("oid")
        if not user:
            log.warning(json.dumps({"event": "token_rejected", "reason": "no_user_claim"}))
            return None
        role = resolve_role(self.cfg, str(user), list(claims.get("groups", [])))

        return EntraAccessToken(
            token=token,
            client_id=str(claims.get("azp") or claims.get("appid") or ""),
            scopes=scopes,
            expires_at=int(claims["exp"]),
            user=str(user),
            role=role,
        )
