"""Synthetic Essbase-style cube modelled on Sample.Basic / Demo.Basic.

All numbers are generated deterministically and are NOT real client data.
The shape (Year, Measures, Product, Market, Scenario) mirrors the on-prem
Demo.Basic app so the demo behaves like the real server.
"""

from __future__ import annotations

import random
from dataclasses import dataclass

MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
QUARTERS = {
    "Qtr1": ["Jan", "Feb", "Mar"],
    "Qtr2": ["Apr", "May", "Jun"],
    "Qtr3": ["Jul", "Aug", "Sep"],
    "Qtr4": ["Oct", "Nov", "Dec"],
}
MARKETS = ["East", "West", "South", "Central"]
PRODUCTS = {
    "100": "Colas",
    "200": "Root Beer",
    "300": "Cream Soda",
    "400": "Fruit Soda",
}
SCENARIOS = ["Actual", "Budget"]
BASE_MEASURES = ["Sales", "COGS", "Marketing", "Payroll"]
DERIVED_MEASURES = {
    "Margin": "Sales - COGS",
    "Total Expenses": "Marketing + Payroll",
    "Profit": "Margin - Total Expenses",
    "Margin %": "Margin / Sales * 100",
}
MEASURES = BASE_MEASURES + list(DERIVED_MEASURES)

DIMENSIONS = {
    "Year": ["Year"] + list(QUARTERS) + MONTHS,
    "Measures": MEASURES,
    "Product": ["Product"] + [f"{k} {v}" for k, v in PRODUCTS.items()],
    "Market": ["Market"] + MARKETS,
    "Scenario": SCENARIOS + ["Variance", "Variance %"],
}


@dataclass(frozen=True)
class Cell:
    month: str
    market: str
    product: str
    scenario: str


def _build() -> dict[Cell, dict[str, float]]:
    rng = random.Random(20260926)
    market_size = {"East": 1.25, "West": 1.1, "South": 0.7, "Central": 0.95}
    product_size = {"100": 1.3, "200": 0.9, "300": 0.75, "400": 1.0}
    data: dict[Cell, dict[str, float]] = {}
    for mi, month in enumerate(MONTHS):
        season = 1 + 0.18 * (1 if mi in (5, 6, 7) else 0) - 0.08 * (1 if mi in (0, 1) else 0)
        for market in MARKETS:
            for prod in PRODUCTS:
                base = 10_000 * market_size[market] * product_size[prod] * season
                actual_sales = round(base * rng.uniform(0.9, 1.12))
                budget_sales = round(base * rng.uniform(0.97, 1.05))
                for scen, sales in (("Actual", actual_sales), ("Budget", budget_sales)):
                    cogs_ratio = rng.uniform(0.42, 0.5) if scen == "Actual" else 0.45
                    data[Cell(month, market, prod, scen)] = {
                        "Sales": float(sales),
                        "COGS": float(round(sales * cogs_ratio)),
                        "Marketing": float(round(sales * rng.uniform(0.12, 0.16))),
                        "Payroll": float(round(1_800 * market_size[market])),
                    }
    return data


_DATA = _build()


def resolve_months(period: str) -> list[str]:
    p = period.strip()
    if p in ("Year", "", "Total"):
        return MONTHS
    if p in QUARTERS:
        return QUARTERS[p]
    for m in MONTHS:
        if p.lower().startswith(m.lower()):
            return [m]
    raise ValueError(f"Unknown period '{period}'. Use Year, Qtr1-Qtr4 or Jan-Dec.")


def resolve_product(product: str) -> list[str]:
    p = product.strip().lower()
    if p in ("product", "all", "total", ""):
        return list(PRODUCTS)
    for code, name in PRODUCTS.items():
        if p in (code, name.lower(), f"{code} {name}".lower()):
            return [code]
    raise ValueError(f"Unknown product '{product}'. Use one of: {', '.join(PRODUCTS.values())}.")


def normalize_market(market: str) -> str:
    for m in MARKETS:
        if market.strip().lower() == m.lower():
            return m
    raise ValueError(f"Unknown market '{market}'. Use one of: {', '.join(MARKETS)}.")


def _base_totals(months: list[str], markets: list[str], products: list[str], scenario: str) -> dict[str, float]:
    tot = {m: 0.0 for m in BASE_MEASURES}
    for month in months:
        for market in markets:
            for prod in products:
                cell = _DATA[Cell(month, market, prod, scenario)]
                for k in BASE_MEASURES:
                    tot[k] += cell[k]
    return tot


def value(measure: str, months: list[str], markets: list[str], products: list[str], scenario: str) -> float:
    if scenario not in SCENARIOS:
        raise ValueError(f"Unknown scenario '{scenario}'. Use Actual or Budget.")
    t = _base_totals(months, markets, products, scenario)
    margin = t["Sales"] - t["COGS"]
    expenses = t["Marketing"] + t["Payroll"]
    all_values = {
        **t,
        "Margin": margin,
        "Total Expenses": expenses,
        "Profit": margin - expenses,
        "Margin %": round(margin / t["Sales"] * 100, 2) if t["Sales"] else 0.0,
    }
    for key, v in all_values.items():
        if key.lower() == measure.strip().lower():
            return round(v, 2)
    raise ValueError(f"Unknown measure '{measure}'. Use one of: {', '.join(MEASURES)}.")
