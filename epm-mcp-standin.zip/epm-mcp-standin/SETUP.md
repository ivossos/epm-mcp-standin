# Setup: Entra ID + public host + Copilot Studio

About 45 minutes. Steps marked **(you)** involve secrets, creating accounts or
paying for hosting, so Yannis does those himself. The rest can be done
together in the browser.

## 1. Test users (you)

In your Microsoft 365 / Entra tenant, create or pick three users:
`exec@…`, `east@…`, `west@…`. Any existing accounts work. You can also use
groups later (`GROUP_ROLES`).

## 2. App registration A — the MCP server (the API)

Entra admin center → App registrations → New registration

- Name: `EPMCopilot-MCP-Server`, single tenant, no redirect URI
- Expose an API → Application ID URI: accept `api://<client-id>`
- Add a scope: `access_as_user`, "Admins and users", enabled
- Manifest: set `"requestedAccessTokenVersion": 2` (older portals call it `accessTokenAcceptedVersion`)
- Note: **Directory (tenant) ID** and **Application (client) ID**

## 3. App registration B — Copilot Studio (the client)

- Name: `EPMCopilot-CopilotStudio`, single tenant
- Certificates & secrets → New client secret → **copy the value (you)**, you only see it once
- API permissions → My APIs → `EPMCopilot-MCP-Server` → `access_as_user` (delegated),
  plus Microsoft Graph `openid`, `profile`, `email`, `offline_access` → Grant admin consent
- Redirect URI: added in step 6

## 4. Deploy the server to a public HTTPS host (you pick the account)

Render (fastest): New → Blueprint → point at this repo (uses `render.yaml`), then set:

| Variable | Value |
| --- | --- |
| `PUBLIC_URL` | the service URL, e.g. `https://epm-copilot-mcp-standin.onrender.com` |
| `ENTRA_TENANT_ID` | tenant ID from step 2 |
| `ENTRA_AUDIENCE` | `api://<server-client-id>,<server-client-id>` |
| `USER_ROLES` | `{"exec@…":"exec","east@…":"east","west@…":"west"}` |

Check: `https://<host>/health` → `{"status":"ok","auth":"entra"}` and
`https://<host>/mcp` without a token → `401`.

Azure App Service or Container Apps in your own subscription work the same
way with the `Dockerfile`.

## 5. Copilot Studio — add the MCP tool

Agent **EPM Copilot - Essbase** (already created) → Tools → Add → Model Context Protocol:

| Field | Value |
| --- | --- |
| Server name | EPM Copilot |
| Server URL | `https://<host>/mcp` |
| Authentication | OAuth 2.0 → Manual |
| Client ID | app B client ID |
| Client secret | app B secret **(you type it)** |
| Authorization URL | `https://login.microsoftonline.com/<tenant-id>/oauth2/v2.0/authorize` |
| Token URL / Refresh URL | `https://login.microsoftonline.com/<tenant-id>/oauth2/v2.0/token` |
| Scopes | `api://<server-client-id>/access_as_user offline_access` |

## 6. Redirect URI

Copilot Studio shows a callback like `https://global.consent.azure-apim.net/redirect/…`.
Paste it exactly into app B → Authentication → Add a platform → Web.

## 7. Test, then publish

1. In the tool, **Create new connection**, sign in as `east@…`
2. Preview: "who am I?", then "Sales by market for Qtr1", then "show West margin" → should be refused
3. Repeat as `exec@…` and `west@…`
4. Publish → Channels → Teams and Microsoft 365 Copilot

## Claude as the second front end

Claude's connector needs the same server. Because Entra has no dynamic client
registration, add a third app registration for Claude (redirect
`https://claude.ai/api/mcp/auth_callback`) and enter its client ID and secret
in the connector's advanced settings. Test this as part of the phase 1 spike.

## Switching to the real server later

Replace the synthetic `app/cube.py` calls with the on-prem Essbase REST calls,
keep `app/auth.py` and the role checks, and deploy behind ThoughtLogic's public
hostname. Entra and Copilot Studio only need the new URL.
